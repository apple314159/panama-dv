=======
Credits
=======

Development Lead
----------------

* Jose Vasconcellos @apple314159 on GitHub

Contributors
------------

* Vauxoo <info@vauxoo.com>
