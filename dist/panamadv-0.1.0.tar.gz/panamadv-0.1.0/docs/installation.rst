============
Installation
============

At the command line::

    $ easy_install panamadv

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv panamadv
    $ pip install panamadv
