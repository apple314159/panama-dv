========
Usage
========

To use panamadv in a project::

    import panamadv
