# -*- coding: utf-8 -*-

__author__ = 'Vauxoo'
__email__ = 'info@vauxoo.com'
__version__ = '0.1.0'
import ruc
