===============================
panamadv
===============================

.. image:: https://img.shields.io/travis/Vauxoo/panamadv.svg
        :target: https://travis-ci.org/Vauxoo/panamadv

.. image:: https://img.shields.io/pypi/v/panamadv.svg
        :target: https://pypi.python.org/pypi/panamadv


Program to calculate the DV for the given RUC for Panama.

* Free software: BSD license
* Documentation: https://panamadv.readthedocs.org.

Features
--------

* TODO
